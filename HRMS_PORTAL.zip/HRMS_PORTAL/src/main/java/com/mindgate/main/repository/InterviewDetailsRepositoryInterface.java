package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.InterviewDetails;

public interface InterviewDetailsRepositoryInterface {

	public List<InterviewDetails> getAllInterviewDetails();

	public InterviewDetails addNewInterviewDetails(InterviewDetails interviewDetails);

	public boolean updateInterviewDetails(InterviewDetails interviewDetails);

	public List<InterviewDetails> getAllInterviewDetailsByStatus();

	// After interview update status----->passed
	public boolean updateInterviewDetailsStatus(InterviewDetails interviewDetails);

	// After interview update status----->SentMail
	public boolean updateInterviewDetailsStatusForMail(InterviewDetails interviewDetails);
}
