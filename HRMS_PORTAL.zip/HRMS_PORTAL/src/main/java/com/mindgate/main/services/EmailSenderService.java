package com.mindgate.main.services;

import java.io.File;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import org.springframework.stereotype.Service;

import com.mindgate.main.domain.SendEmail;

@Service
public class EmailSenderService implements EmailSenderServiceInterface {

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${spring.mail.username}")
	private String sender;
	
	 public String
	    sendMailWithAttachment(SendEmail sendEmail)
	    {
	        // Creating a mime message
	        MimeMessage mimeMessage
	            = javaMailSender.createMimeMessage();
	        
	        MimeMessageHelper mimeMessageHelper;
	 
	        try {
	 
	         
	        	mimeMessageHelper = new MimeMessageHelper(mimeMessage);
	        	
	            mimeMessageHelper
	                = new MimeMessageHelper(mimeMessage, true);
	            mimeMessageHelper.setFrom(sender);
	            mimeMessageHelper.setTo(sendEmail.getRecipient());
	            mimeMessageHelper.setText(sendEmail.getMsgBody());
	            mimeMessageHelper.setSubject(
	            		sendEmail.getSubject());
	 
	            // Adding the attachment
	            FileSystemResource file
	                = new FileSystemResource(
	                    new File(sendEmail.getAttachment()));
	 
	            mimeMessageHelper.addAttachment(
	                file.getFilename(), file);
	 
	            // Sending the mail
	            javaMailSender.send(mimeMessage);
	            return "Mail sent Successfully";
	        }
	 
	        // Catch block to handle MessagingException
	        catch (MessagingException e) {
	 
	            // Display message when exception occurred
	            return "Error while sending mail!!!";
	        }
	    }
}

