package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.ApplicantDetails;

public interface ApplicantDetailsRepositoryInterface {


	public List<ApplicantDetails> getAllAppicantDetails();
	
	public boolean addNewApplicantDetails(ApplicantDetails applicantDetails);

	public boolean updateApplicantDetailsStatus(ApplicantDetails applicantDetails);
	public List<ApplicantDetails> getAllAppicantDetailsByStatus();
	public boolean updateApplicantDetailsSelectedStatus(ApplicantDetails applicantDetails);
	
}
