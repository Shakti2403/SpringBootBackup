package com.mindgate.main.services;

import java.util.List;

import com.mindgate.main.domain.ApplicantDetails;

public interface ApplicantDetailsServiceInterface {

	public List<ApplicantDetails> getAllAppicantDetails();

	public boolean addNewApplicantDetails(ApplicantDetails applicantDetails);

	public boolean updateApplicantDetailsStatus(ApplicantDetails applicantDetails);

	public List<ApplicantDetails> getAllAppicantDetailsByStatus();

	public boolean updateApplicantDetailsSelectedStatus(ApplicantDetails applicantDetails);

}
