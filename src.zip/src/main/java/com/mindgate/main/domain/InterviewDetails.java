package com.mindgate.main.domain;

import java.util.Objects;

public class InterviewDetails {

	private int interviewId;
	private int applicantId;
	private int employeeId;
	private String feedback;
	private String status;

	public InterviewDetails() {
		// TODO Auto-generated constructor stub
	}

	public InterviewDetails(int interviewId, int applicantId, int employeeId, String feedback, String status) {
		super();
		this.interviewId = interviewId;
		this.applicantId = applicantId;
		this.employeeId = employeeId;
		this.feedback = feedback;
		this.status = status;
	}

	public int getInterviewId() {
		return interviewId;
	}

	public void setInterviewId(int interviewId) {
		this.interviewId = interviewId;
	}

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "InterviewDetails [interviewId=" + interviewId + ", applicantId=" + applicantId + ", employeeId="
				+ employeeId + ", feedback=" + feedback + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(applicantId, employeeId, feedback, interviewId, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InterviewDetails other = (InterviewDetails) obj;
		return applicantId == other.applicantId && employeeId == other.employeeId
				&& Objects.equals(feedback, other.feedback) && interviewId == other.interviewId
				&& Objects.equals(status, other.status);
	}

}
