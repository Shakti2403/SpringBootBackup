package com.mindgate.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.repository.ApplicantDetailsRepositoryInterface;

@Service
public class ApplicantDetailsService implements ApplicantDetailsRepositoryInterface {

	@Autowired
	private ApplicantDetailsRepositoryInterface applicantDetailsRepositoryInterface;
	
	
	@Override
	public List<ApplicantDetails> getAllAppicantDetails() {
		// TODO Auto-generated method stub
		return applicantDetailsRepositoryInterface.getAllAppicantDetails();
	}

}
