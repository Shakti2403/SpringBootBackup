package com.mindgate.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.InterviewDetails;
import com.mindgate.main.repository.ApplicantDetailsRepositoryInterface;
import com.mindgate.main.repository.InterviewDetailsRepositoryInterface;

@Service
public class InterviewDetailsService implements InterviewDetailsServiceInterface {

	@Autowired
	private InterviewDetailsRepositoryInterface interviewDetailsRepositoryInterface;
	
	@Autowired
	private ApplicantDetailsRepositoryInterface applicantDetailsRepositoryInterface;

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		List<InterviewDetails> allInterviewDetails = interviewDetailsRepositoryInterface.getAllInterviewDetails();
		
		for (InterviewDetails interviewDetails : allInterviewDetails) {
			interviewDetails.setApplicantDetails(applicantDetailsRepositoryInterface.getSingleApplicantDetails(interviewDetails.getApplicantDetails().getApplicantId()));
		}
		System.out.println(allInterviewDetails);
		return allInterviewDetails;
				
	}

	@Override
	public InterviewDetails addNewInterviewDetails(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.addNewInterviewDetails(interviewDetails);
	}

	@Override
	public boolean updateInterviewDetails(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.updateInterviewDetails(interviewDetails);
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetailsByStatus() {
		// TODO Auto-generated method stub
		List<InterviewDetails> allInterviewDetails =  interviewDetailsRepositoryInterface.getAllInterviewDetailsByStatus();
		for (InterviewDetails interviewDetails : allInterviewDetails) {
			interviewDetails.setApplicantDetails(applicantDetailsRepositoryInterface.getSingleApplicantDetails(interviewDetails.getApplicantDetails().getApplicantId()));
		}
		return allInterviewDetails;
	}

	// After interview update status----->passed
	@Override
	public boolean updateInterviewDetailsStatus(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.updateInterviewDetailsStatus(interviewDetails);
	}

	// After interview update status----->SentMail
	@Override
	public boolean updateInterviewDetailsStatusForMail(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.updateInterviewDetailsStatusForMail(interviewDetails);
	}

}
