package com.mindgate.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.InterviewDetails;
import com.mindgate.main.repository.ApplicantDetailsRepositoryInterface;
import com.mindgate.main.repository.InterviewDetailsRepositoryInterface;

@Service
public class InterviewDetailsService implements InterviewDetailsServiceInterface {

	@Autowired
	private InterviewDetailsRepositoryInterface interviewDetailsRepositoryInterface;
	
	
	
	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.getAllInterviewDetails();
	}



	@Override
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.addNewInterviewDetails(interviewDetails);
	}



	@Override
	public boolean updateInterviewDetails(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.updateInterviewDetails(interviewDetails);
	}



	@Override
	public List<InterviewDetails> getAllInterviewDetailsByStatus() {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.getAllInterviewDetailsByStatus();
	}


	// After interview update status----->passed
	@Override
	public boolean updateInterviewDetailsStatus(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepositoryInterface.updateInterviewDetailsStatus(interviewDetails);
	}

}
