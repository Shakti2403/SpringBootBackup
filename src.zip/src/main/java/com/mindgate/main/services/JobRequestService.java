package com.mindgate.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.JobRequest;
import com.mindgate.main.repository.JobRequestDetailsRepositoryInterface;

@Service
public class JobRequestService implements JobRequestDetailsServiceInterface {
	@Autowired
	private JobRequestDetailsRepositoryInterface jobRequestRepositoryInterface;

	@Override
	public boolean addNewJobRequest(JobRequest jobrequest) {
		return jobRequestRepositoryInterface.addNewJobRequest(jobrequest);
	}

	@Override
	public List<JobRequest> getAllJobRequest() {

		return jobRequestRepositoryInterface.getAllJobRequest();
	}

	@Override
	public boolean updateJobRequest(JobRequest jobrequest) {
		return jobRequestRepositoryInterface.updateJobRequest(jobrequest);
	}

	@Override
	public List<JobRequest> getJobRequestByUserId(int userId) {

		return jobRequestRepositoryInterface.getJobRequestByUserId(userId);
	}

	@Override
	public List<JobRequest> getJobRequestByManagerUserId(int userId) {
		return jobRequestRepositoryInterface.getJobRequestByManagerUserId(userId);
	}

	@Override
	public JobRequest getSingleJobRequest(int jobId) {
		return jobRequestRepositoryInterface.getSingleJobRequest(jobId);
	}

	@Override
	public boolean updateJobRequestStatus(JobRequest jobrequest) {
		// TODO Auto-generated method stub
		return jobRequestRepositoryInterface.updateJobRequestStatus(jobrequest);
	}

	@Override
	public boolean updateJobRequestCount(JobRequest jobrequest) {
		return jobRequestRepositoryInterface.updateJobRequestCount(jobrequest);
	}

	@Override
	public List<JobRequest> getAllJobRequestByStatus() {
		// TODO Auto-generated method stub
		return jobRequestRepositoryInterface.getAllJobRequestByStatus();
	}

}
