package com.mindgate.main.services;


import com.mindgate.main.domain.SendEmail;

public interface EmailSenderServiceInterface {


	String sendMailWithAttachment(SendEmail sendEmail);
}