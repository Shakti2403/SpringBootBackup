package com.mindgate.main.services;

import java.util.List;

import com.mindgate.main.domain.InterviewDetails;

public interface InterviewDetailsServiceInterface {

	public List<InterviewDetails> getAllInterviewDetails();

	public boolean addNewInterviewDetails(InterviewDetails interviewDetails);

	public boolean updateInterviewDetails(InterviewDetails interviewDetails);

	public List<InterviewDetails> getAllInterviewDetailsByStatus();

	// After interview update status----->passed
	public boolean updateInterviewDetailsStatus(InterviewDetails interviewDetails);
}
