package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.JobRequest;

public interface JobRequestDetailsRepositoryInterface {

	public boolean addNewJobRequest(JobRequest jobrequest);

	public List<JobRequest> getAllJobRequest();

	public boolean updateJobRequest(JobRequest jobrequest);

	public List<JobRequest> getJobRequestByUserId(int userId);

	List<JobRequest> getJobRequestByManagerUserId(int userId);

	public JobRequest getSingleJobRequest(int jobId);
	
	public boolean updateJobRequestStatus(JobRequest jobrequest);
	
	public boolean updateJobRequestCount(JobRequest jobrequest);
	
	public List<JobRequest> getAllJobRequestByStatus();
	

}
