package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.EmployeeDetails;

@Repository
public class EmployeeDetailsRepository implements EmployeeDetailsRepositoryInterface {

	private static final String SELECT_SINGLE_EMPLOYEE_DETAILS = "select * from employee_details where user_id=?";
	private static final String EMPLOYEE_DETAILS_BY_EMPLOYEEID = "select j.job_id , j.project_id , j.employee_id , j.skill_1 , j.skill_2 , j.skill_3 , j.count ,j.status,e.employee_id, e.first_name , e.last_name , e.contact, e.designation , e.skill_1 as employee_skill_1 , e.skill_2 as employee_skill_2 , e.skill_3 as employee_skill_3 , e.bench , e.salary , e.address, e.city , e.state, e.pin_code , e.user_id ,e.mgr from job_request j , employee_details e where  e.project_id=1000 and j.status='pending'";
	private static final String EMPLOYEE_DETAILS_BY_JOBID = "select * from employee_details e , job_request j where e.bench='Yes' and e.skill_1=j.skill_1 and e.skill_2=j.skill_2 and e.skill_3=j.skill_3 and  j.job_id=?";
	private static final String EMPLOYEE_DETAILS_ASSIGN = "update employee_details set mgr = ? , project_id = ? , bench = ? where employee_id = ?";
	private static final String INSERT_NEW_EMPLOYEE_DETAILS ="insert into employee_details(employee_id,first_name,last_name,contact,designation,skill_1,skill_2,skill_3,bench,salary,address,city,state,pincode,user_id,project_id,mgr) values(employee_id_sequence.nextVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public EmployeeDetails getByLoginId(int loginId) {
		EmployeeDetails employeeDetails = jdbcTemplate.queryForObject(SELECT_SINGLE_EMPLOYEE_DETAILS,
				new EmployeeDetailsRowMapper(), loginId);
		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetailsByProjectId(int projectId) {
		List<EmployeeDetails> employeeDetails = jdbcTemplate.query(EMPLOYEE_DETAILS_BY_EMPLOYEEID,
				new EmployeeDetailsRowMapper());
		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetailsByJobId(int jobId) {
		List<EmployeeDetails> employeeDetails = jdbcTemplate.query(EMPLOYEE_DETAILS_BY_JOBID,
				new EmployeeDetailsRowMapper(), jobId);
		return employeeDetails;
	}

	@Override
	public boolean updateEmployeeDetailsAssign(EmployeeDetails employeeDetails) {
		Object[] params = { employeeDetails.getMgr(), employeeDetails.getProjectDetails().getProjectId(), employeeDetails.getBench() , 
				employeeDetails.getEmployeeId() };
		int result = jdbcTemplate.update(EMPLOYEE_DETAILS_ASSIGN, params);
		if (result > 0)
			return true;
		return false;
	}

	//To Add New Employee After Candidate Selection
	@Override
	public boolean addNewEmployeeDetails(EmployeeDetails employeeDetails) {
		System.out.println(employeeDetails);
		Object[] params = { employeeDetails.getFirstName(),employeeDetails.getLastName(),employeeDetails.getContact(),
				            employeeDetails.getSkill1(),employeeDetails.getSkill2(),employeeDetails.getSkill3(),employeeDetails.getBench(),
				            employeeDetails.getSalary(),employeeDetails.getAddress(),employeeDetails.getCity(),employeeDetails.getState(),
				            employeeDetails.getPincode(),employeeDetails.getLogin().getUserId(),employeeDetails.getProjectDetails().getProjectId()
		};
		int result = jdbcTemplate.update(INSERT_NEW_EMPLOYEE_DETAILS, params);
		if (result > 0) {
			return true;
		}
		return false;
	}

}
