package com.mindgate.main.repository;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.DocumentDetails;

public class DocumentDetailsRowMapper implements RowMapper<DocumentDetails> {

	@Override
	public DocumentDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		int documentId = rs.getInt("document_id");
		String documentName = rs.getString("document_name");
		String documentType = rs.getString("document_type");
		Blob document = rs.getBlob("document");
		
		DocumentDetails documentDetails = new  DocumentDetails(documentId, documentName, documentType, document);
		
		
		return documentDetails;
	}

	
	
}
