package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.JobRequest;

@Repository
public class ApplicantDetailsRepository implements ApplicantDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String GET_ALL_APPLICANT_DETAILS = "select * from applicant_details"; 
	private static final String INSERT_NEW_APPLICANT_DETAILS ="insert into applicant_details (applicant_id,applicant_name,mail_id,contact_number,skill_1,skill_2,skill_3,qualification,experience,status,job_id,document_id) values(applicant_id_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?,1000,?)";
	private static final String UPDATE_APPLICANT_DETAILS_STATUS_BY_APPLICANT_ID ="update applicant_details set status='Send For Interview'  where applicant_id=?";
	
	@Override
	public List<ApplicantDetails> getAllAppicantDetails() {
		List<ApplicantDetails> applicantDetails = jdbcTemplate.query(GET_ALL_APPLICANT_DETAILS, new ApplicantDetailsRowMapper());
		return applicantDetails;
	}

	@Override
	public boolean addNewApplicantDetails(ApplicantDetails applicantDetails) {
		System.out.println(applicantDetails);
		Object[] params = { applicantDetails.getApplicantName(),applicantDetails.getMailId(),
			                 applicantDetails.getContactNumber(),applicantDetails.getSkill1(),
			                 applicantDetails.getSkill2(),applicantDetails.getSkill3(),applicantDetails.getQualification(),
			                 applicantDetails.getExperience(),applicantDetails.getStatus(),
			                 applicantDetails.getDocumentId()};
		int result = jdbcTemplate.update(INSERT_NEW_APPLICANT_DETAILS, params);
		if (result > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateApplicantDetailsStatus(ApplicantDetails applicantDetails) {
		Object[] params = { applicantDetails.getApplicantId() };
		int result = jdbcTemplate.update(UPDATE_APPLICANT_DETAILS_STATUS_BY_APPLICANT_ID, params);
		if (result > 0)
			return true;
		return false;
	}

}
