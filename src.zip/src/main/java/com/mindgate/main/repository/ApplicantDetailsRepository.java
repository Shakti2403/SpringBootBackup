package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.JobRequest;

@Repository
public class ApplicantDetailsRepository implements ApplicantDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String GET_ALL_APPLICANT_DETAILS = "select * from applicant_details"; 
	
	@Override
	public List<ApplicantDetails> getAllAppicantDetails() {
		List<ApplicantDetails> applicantDetails = jdbcTemplate.query(GET_ALL_APPLICANT_DETAILS, new ApplicantDetailsRowMapper());
		return applicantDetails;
	}

}
