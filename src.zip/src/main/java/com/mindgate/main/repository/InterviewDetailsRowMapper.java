package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.InterviewDetails;

public class InterviewDetailsRowMapper implements RowMapper<InterviewDetails> {

	@Override
	public InterviewDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		int interview_id = rs.getInt("interview_id");
		int applicant_id = rs.getInt("applicant_id");
		int employee_id = rs.getInt("employee_id");
		String feedback =rs.getString("feedback");
		String status =rs.getString("status");
		
		InterviewDetails  interviewDetails = new InterviewDetails(interview_id, applicant_id, employee_id, feedback, status);		
		return interviewDetails;
	}

}
