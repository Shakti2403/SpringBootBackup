package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.InterviewDetails;
import com.mindgate.main.domain.ProjectDetails;

public class InterviewDetailsRowMapper implements RowMapper<InterviewDetails> {

	@Override
	public InterviewDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		InterviewDetails  interviewDetails = new InterviewDetails();
		
		int interview_id = rs.getInt("interview_id");
		ApplicantDetails applicantDetails =new ApplicantDetails();
		applicantDetails.setApplicantId(rs.getInt("applicant_id"));
	
		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setEmployeeId(rs.getInt("employee_id"));
		
		int employee_id = rs.getInt("employee_id");
		String feedback =rs.getString("feedback");
		String status =rs.getString("status");
		
		
		interviewDetails.setFeedback(rs.getString("feedback"));
		interviewDetails.setStatus(rs.getString("status"));
		
		return interviewDetails;
	}

}

