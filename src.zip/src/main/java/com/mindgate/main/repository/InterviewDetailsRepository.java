package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.InterviewDetails;

@Repository
public class InterviewDetailsRepository implements InterviewDetailsRepositoryInterface {

	private static final String GET_ALL_INTERVIEW_DETAILS = "select * from interview_details";
	private static final String INSERT_NEW_INTERVIEW_DETAILS = "insert into interview_details(interview_id,applicant_id,employee_id,feedback,status) values(interview_id_sequence.nextVAL,?,1006,?,?)";
	private static final String UPDATE_INTERVIEW_DETAILS_BY_INTERVIEW_ID = "update interview_details set status=? , feedback=?  where interview_id=?";
	private static final String GET_ALL_INTERVIEW_DETAILS_BY_STATUS = "select * from interview_details where status In('Selected','Passed')";
	private static final String UPDATE_INTERVIEW_DETAILS_STATUS="update interview_details set status='Passed' where interview_id=?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	//
	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		List<InterviewDetails> interviewDetails = jdbcTemplate.query(GET_ALL_INTERVIEW_DETAILS,
				new InterviewDetailsRowMapper());
		System.out.println(interviewDetails);

		return interviewDetails;
	}

	@Override
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails) {
		System.out.println(interviewDetails);
		Object[] params = { interviewDetails.getApplicantDetails().getApplicantId(), interviewDetails.getFeedback(),
				interviewDetails.getStatus() };
		int result = jdbcTemplate.update(INSERT_NEW_INTERVIEW_DETAILS, params);
		if (result > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateInterviewDetails(InterviewDetails interviewDetails) {
		Object[] params = { interviewDetails.getStatus(), interviewDetails.getFeedback(),
				interviewDetails.getInterviewId() };
		int result = jdbcTemplate.update(UPDATE_INTERVIEW_DETAILS_BY_INTERVIEW_ID, params);
		if (result > 0)
			return true;
		return false;
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetailsByStatus() {
		List<InterviewDetails> interviewDetails = jdbcTemplate.query(GET_ALL_INTERVIEW_DETAILS_BY_STATUS,
				new InterviewDetailsRowMapper());
		return interviewDetails;
	}

	
	//After interview update status----->passed
	@Override
	public boolean updateInterviewDetailsStatus(InterviewDetails interviewDetails) {
		Object[] params = {	interviewDetails.getInterviewId() };
		int result = jdbcTemplate.update(UPDATE_INTERVIEW_DETAILS_STATUS, params);
		if (result > 0)
			return true;
		return false;
	}
	
	
}
