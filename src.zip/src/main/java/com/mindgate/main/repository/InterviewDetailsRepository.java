package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.InterviewDetails;

@Repository
public class InterviewDetailsRepository implements InterviewDetailsRepositoryInterface {

	private static final String GET_ALL_INTERVIEW_DETAILS = "select * from interview_details"; 
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		List<InterviewDetails> interviewDetails = jdbcTemplate.query(GET_ALL_INTERVIEW_DETAILS, new InterviewDetailsRowMapper());
		System.out.println(interviewDetails);

		return interviewDetails;
	}

	
	
}
