package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.InterviewDetails;
import com.mindgate.main.domain.JobRequest;

public interface InterviewDetailsRepositoryInterface {

	
	public List<InterviewDetails> getAllInterviewDetails();
	
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails);
}
