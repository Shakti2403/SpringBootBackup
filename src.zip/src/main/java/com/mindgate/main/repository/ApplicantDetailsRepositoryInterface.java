package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.JobRequest;

public interface ApplicantDetailsRepositoryInterface {


	public List<ApplicantDetails> getAllAppicantDetails();
	
	public boolean addNewApplicantDetails(ApplicantDetails applicantDetails);

	public boolean updateApplicantDetailsStatus(ApplicantDetails applicantDetails);
	public List<ApplicantDetails> getAllAppicantDetailsByStatus();
	public boolean updateApplicantDetailsSelectedStatus(ApplicantDetails applicantDetails);
	
	public ApplicantDetails getSingleApplicantDetails(int applicantId);
	
	//update status = sent mail
	public boolean updateApplicantDetailsStatusByApplicantId(ApplicantDetails applicantDetails);

 
	
}
