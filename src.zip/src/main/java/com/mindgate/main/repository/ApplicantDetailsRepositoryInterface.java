package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.JobRequest;

public interface ApplicantDetailsRepositoryInterface {


	public List<ApplicantDetails> getAllAppicantDetails();
	
	public boolean addNewApplicantDetails(ApplicantDetails applicantDetails);

}
