package com.mindgate.main.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.SendEmail;
import com.mindgate.main.services.EmailSenderServiceInterface;


@RestController
@CrossOrigin("*")
@RequestMapping("emailSenderapi")
public class EmailController {

	@Autowired
	private EmailSenderServiceInterface emailSenderService;

	@PostMapping("/sendMailWithAttachment")
	public String sendMailWithAttachment(@RequestBody SendEmail sendEmail) {
		String status = emailSenderService.sendMailWithAttachment(sendEmail);

		return status;
	}

}