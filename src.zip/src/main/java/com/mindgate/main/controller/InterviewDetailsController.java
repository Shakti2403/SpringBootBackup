package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.InterviewDetails;
import com.mindgate.main.services.InterviewDetailsServiceInterface;

@RestController
@CrossOrigin("*")
@RequestMapping("interviewdetailsapi")
public class InterviewDetailsController {

	@Autowired
	private InterviewDetailsServiceInterface interviewDetailsServiceInterface;
	
//	http://localhost:8080/interviewdetailsapi/interviewdetails/all
		@RequestMapping(value = "interviewdetails/all", method = RequestMethod.GET)
		public List<InterviewDetails> getAllInterviewDetails() {
			List<InterviewDetails> interviewDetails = interviewDetailsServiceInterface.getAllInterviewDetails();
			System.out.println(interviewDetails);
			return interviewDetails;
		}
	
		

		// http://localhost:8080/interviewdetailsapi/insertnewinterviewdetails
		@RequestMapping(value = "insertnewinterviewdetails", method = RequestMethod.POST)
		public boolean addNewInterviewDetails(@RequestBody InterviewDetails interviewDetails) {
			System.out.println(interviewDetails);
			return interviewDetailsServiceInterface.addNewInterviewDetails(interviewDetails);
		}
}
