package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.JobRequest;
import com.mindgate.main.services.ApplicantDetailsServiceInterface;

@RestController
@CrossOrigin("*")
@RequestMapping("applicantdetailsapi")
public class ApplicantDetailsController {
	
	@Autowired
	private ApplicantDetailsServiceInterface applicantDetailsServiceInterface;
	
	
//	http://localhost:8080/applicantdetailsapi/applicantdetails/all
		@RequestMapping(value = "applicantdetails/all", method = RequestMethod.GET)
		public List<ApplicantDetails> getAlApplicantDetails() {
			List<ApplicantDetails> applicantDetails = applicantDetailsServiceInterface.getAllAppicantDetails();
			System.out.println(applicantDetails);
			return applicantDetails;
		}

		// http://localhost:8080/applicantdetailsapi/insertnewapplicant
		@RequestMapping(value = "insertnewapplicant", method = RequestMethod.POST)
		public boolean addNewApplicantDetails(@RequestBody ApplicantDetails applicantDetails) {
			System.out.println(applicantDetails);
			return applicantDetailsServiceInterface.addNewApplicantDetails(applicantDetails);
		}
		
		
		
}
