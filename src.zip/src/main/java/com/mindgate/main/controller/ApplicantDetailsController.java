package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.JobRequest;
import com.mindgate.main.services.ApplicantDetailsServiceInterface;

@RestController
@CrossOrigin("*")
@RequestMapping("applicantdetailsapi")
public class ApplicantDetailsController {
	
	@Autowired
	private ApplicantDetailsServiceInterface applicantDetailsServiceInterface;
	
	
//	http://localhost:8080/applicantdetailsapi/applicantdetails/all
		@RequestMapping(value = "applicantdetails/all", method = RequestMethod.GET)
		public List<ApplicantDetails> getAlApplicantDetails() {
			List<ApplicantDetails> applicantDetails = applicantDetailsServiceInterface.getAllAppicantDetails();
			return applicantDetails;
		}

		// http://localhost:8080/applicantdetailsapi/insertnewapplicant
		@RequestMapping(value = "insertnewapplicant", method = RequestMethod.POST)
		public boolean addNewApplicantDetails(@RequestBody ApplicantDetails applicantDetails) {
			return applicantDetailsServiceInterface.addNewApplicantDetails(applicantDetails);
		}
		
//		http://localhost:8080/applicantdetailsapi/updateapplicantdetailsbyapplicantid
		@RequestMapping(value = "updateapplicantdetailsbyapplicantid", method = RequestMethod.PUT)
		public boolean updateApplicantDetailsStatus(@RequestBody ApplicantDetails applicantDetails) {
			return applicantDetailsServiceInterface.updateApplicantDetailsStatus(applicantDetails);
		}	
		
		@RequestMapping(value = "updateselectedapplicantdetailsbyapplicantid", method = RequestMethod.PUT)
		public boolean updateSelectedApplicantDetailsStatus(@RequestBody ApplicantDetails applicantDetails) {
			System.out.println();
			System.out.println(applicantDetails);
			System.out.println();
			return applicantDetailsServiceInterface.updateApplicantDetailsSelectedStatus(applicantDetails);
		}	
		

//		http://localhost:8080/applicantdetailsapi/applicantdetailsbystatus/all
			@RequestMapping(value = "applicantdetailsbystatus/all", method = RequestMethod.GET)
			public List<ApplicantDetails> getAllAppicantDetailsByStatus() {
				List<ApplicantDetails> applicantDetails = applicantDetailsServiceInterface.getAllAppicantDetailsByStatus();
				return applicantDetails;
			}
			
			@RequestMapping(value = "applicantbyapplicantid/{applicantId}", method = RequestMethod.GET)
			public ApplicantDetails getSingleApplicantDetails(@PathVariable int applicantId) {
				ApplicantDetails applicantDetails = applicantDetailsServiceInterface.getSingleApplicantDetails(applicantId);
				return applicantDetails;
			}
			
//			http://localhost:8080/applicantdetailsapi/updateapplicantdetailsStatusbyapplicantid
				@RequestMapping(value = "updateapplicantdetailsStatusbyapplicantid", method = RequestMethod.PUT)
				public boolean updateApplicantDetailsStatusByApplicantId(@RequestBody ApplicantDetails applicantDetails) {
					return applicantDetailsServiceInterface.updateApplicantDetailsStatusByApplicantId(applicantDetails);
				}	
		
}
